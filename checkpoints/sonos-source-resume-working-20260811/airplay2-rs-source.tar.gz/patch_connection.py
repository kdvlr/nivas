import re

with open("crates/airplay-client/src/connection.rs", "r") as f:
    content = f.read()

# 1. Expose send_record method
send_record_method = """
    /// Send RECORD request manually (useful for multi-device group streaming).
    pub async fn send_record(&mut self) -> Result<()> {
        let record_req = RtspRequest::record_with_info(
            self.session.request_uri(),
            0,
            0,
        );
        match tokio::time::timeout(
            std::time::Duration::from_secs(2),
            self.rtsp.send(record_req)
        ).await {
            Ok(Ok(resp)) => {
                if resp.status_code == 200 {
                    tracing::info!("RECORD acknowledged");
                } else {
                    tracing::warn!("RECORD returned status {}", resp.status_code);
                }
            }
            Ok(Err(e)) => tracing::warn!("RECORD failed: {}", e),
            Err(_) => tracing::warn!("RECORD timed out"),
        }
        self.session.start_playing()?;
        self.playback_state = PlaybackState::Playing;
        Ok(())
    }
"""

if "pub async fn send_record(" not in content:
    # Insert before start_streaming
    content = content.replace("    pub async fn start_streaming(&mut self, decoder: AudioDecoder) -> Result<()> {", send_record_method + "\n    pub async fn start_streaming(&mut self, decoder: AudioDecoder) -> Result<()> {")


# 2. Add start_streaming_multi method
start_streaming_multi_method = """
    /// Start audio streaming from a decoder source to multiple RTP senders simultaneously.
    pub async fn start_streaming_multi(&mut self, senders: Vec<airplay_audio::RtpSender>, decoder: AudioDecoder) -> Result<()> {
        // Ensure setup is complete
        if self.session.state() != SessionState::Ready {
            self.setup().await?;
        }

        tracing::info!("DIAG: Starting multi-speaker streamer with {} targets", senders.len());

        // Start streamer
        let mut streamer = AudioStreamer::new(self.stream_config.clone());
        streamer.set_rtp_senders(senders).await;
        
        if self.render_delay_ms > 0 {
            streamer.set_render_delay_ms(self.render_delay_ms).await;
        }
        if let Some(offset) = self.timing_offset {
            streamer.set_timing_offset(offset).await;
        }
        if let Some(ref tx) = self.timing_tx {
            streamer.set_timing_updates(tx.subscribe()).await;
        }
        // Enable PTP sync mode (PT=87) if we have a remote clock ID from BMCA
        if self.stream_config.timing_protocol == TimingProtocol::Ptp {
            if let Some(clock_id) = self.ptp_master_clock_id {
                streamer.set_ptp_sync_mode(clock_id).await;
            }
        }

        // Set up equalizer if configured
        if let (Some(config), Some(params)) = (self.eq_config.take(), self.eq_params.clone()) {
            streamer.set_eq_params(config, params).await;
        }

        // FLUSH before streaming
        let flush_req = RtspRequest::flush_with_info(
            self.session.request_uri(),
            0,
            0,
        );
        if let Err(e) = self.rtsp.send(flush_req).await {
            tracing::warn!("FLUSH failed (continuing anyway): {}", e);
        }

        streamer.start(decoder).await?;

        // Send SET_PARAMETER volume to ensure not muted
        if let Err(e) = self.set_volume(self.volume).await {
            tracing::warn!("Failed to set volume: {}", e);
        }

        self.streamer = Some(streamer);
        self.playback_state = PlaybackState::Playing;

        Ok(())
    }
"""

if "pub async fn start_streaming_multi" not in content:
    content = content.replace("    pub async fn start_streaming(&mut self, decoder: AudioDecoder) -> Result<()> {", start_streaming_multi_method + "\n    pub async fn start_streaming(&mut self, decoder: AudioDecoder) -> Result<()> {")


with open("crates/airplay-client/src/connection.rs", "w") as f:
    f.write(content)
