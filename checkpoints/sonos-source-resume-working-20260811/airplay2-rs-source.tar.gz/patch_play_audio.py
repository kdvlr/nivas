import re

with open("crates/airplay-client/examples/play_audio.rs", "r") as f:
    content = f.read()

# Replace the connection loop and playback start
loop_start = content.find("        println!(\"\\n--- Connecting (AirPlay 2 to {} devices) ---\", ips.len());")
loop_end = content.find("        let mut feedback_counter = 0u32;")

if loop_start != -1 and loop_end != -1:
    new_loop = """
        println!("\\n--- Connecting (AirPlay 2 to {} devices) ---", ips.len());
        let mut conns = Vec::new();
        let shared_group_uuid = uuid::Uuid::new_v4();
        
        for (idx, target_ip) in ips.iter().enumerate() {
            let dev_id_str = format!("4E:44:4C:1E:C3:{:02X}", idx + 1);
            let dev_id = DeviceId::from_mac_string(&dev_id_str)?;
            let mut dev = Device {
                id: dev_id,
                name: format!("AirPlay Target {}", idx + 1),
                model: "Unknown".to_string(),
                manufacturer: None,
                serial_number: None,
                addresses: vec![*target_ip],
                port,
                features: default_features,
                required_sender_features: None,
                public_key: None,
                source_version: Default::default(),
                firmware_version: None,
                os_version: None,
                protocol_version: None,
                requires_password: false,
                status_flags: 0,
                access_control: None,
                pairing_identity: None,
                system_pairing_identity: None,
                bluetooth_address: None,
                homekit_home_id: None,
                group_id: Some(shared_group_uuid), // Shared group UUID for synchronized multi-room!
                is_group_leader: false,
                group_public_name: None,
                group_contains_discoverable_leader: false,
                home_group_id: None,
                household_id: None,
                parent_group_id: None,
                parent_group_contains_discoverable_leader: false,
                tight_sync_id: None,
                raop_port: None,
                raop_encryption_types: None,
                raop_codecs: None,
                raop_transport: None,
                raop_metadata_types: None,
                raop_digest_auth: false,
                vodka_version: None,
            };
            
            println!("Connecting to {} ({:?})...", target_ip, dev_id_str);
            let mut conn = Connection::connect_auto(dev, config.clone(), "3939").await?;
            if render_delay_ms > 0 {
                conn.set_render_delay_ms(render_delay_ms);
            }
            conn.setup().await?;
            if let Some(vol) = initial_volume {
                let _ = conn.set_volume(vol).await;
            }
            conns.push(conn);
        }
        println!("All {} devices connected and setup complete!", conns.len());

        println!("\\n--- Starting synchronized playback on all speakers ---");
        
        let mut senders = Vec::new();
        for conn in conns.iter_mut() {
            let sender = conn.build_rtp_sender()?;
            senders.push(sender);
            
            // Put connection into RECORD/Playing state
            conn.send_record().await?;
            
            let _ = conn.send_metadata("10-Sec Test Song", "AirPlay 2 Multi", "Nivas AirPlay").await;
        }
        
        // Start streaming on the FIRST connection, providing ALL senders!
        // This creates ONE AudioStreamer thread that broadcasts identical 
        // packets to all targets at the exact same time.
        let dec = AudioDecoder::open(audio_path)?;
        conns[0].start_streaming_multi(senders, dec).await?;
        println!("Synchronized streaming started across {} targets!", ips.len());
"""
    content = content[:loop_start] + new_loop.strip() + "\n\n" + content[loop_end:]
    
    with open("crates/airplay-client/examples/play_audio.rs", "w") as f:
        f.write(content)
